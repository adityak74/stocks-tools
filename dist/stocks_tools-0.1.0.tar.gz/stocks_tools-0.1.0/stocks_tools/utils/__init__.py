"""Stock Tools Utils Module"""
