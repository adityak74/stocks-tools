"""Announcer Initialization"""
